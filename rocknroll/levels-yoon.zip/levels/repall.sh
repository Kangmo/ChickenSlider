find ./MAP01 -type f -exec ./replace_script.sh {} \;
find ./MAP02 -type f -exec ./replace_script.sh {} \;
